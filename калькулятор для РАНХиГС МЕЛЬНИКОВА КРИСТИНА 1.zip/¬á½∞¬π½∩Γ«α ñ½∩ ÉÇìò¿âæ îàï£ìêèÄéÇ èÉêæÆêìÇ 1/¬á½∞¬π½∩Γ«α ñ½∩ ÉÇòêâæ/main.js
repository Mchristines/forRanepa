let num_one = '' // first num 
let num_two = '' // second num 
let sign = '' // знак операции 
let finish = false 
const digit = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'] 
const action = ['-', '+', 'X', '/'] // здесь привязка к тексту, который прописан внутри кнопок 

const out = document.querySelector('.calc-screen p')

function clearAll() {
    num_one = ''
    num_two = ''
    sing = ''
    finish = false
    out.textContent = 0
}

document.querySelector('.ac').onclick = clearAll

document.querySelector('.buttons').onclick = (event) => {
   // нажата кнопка  

   if (!event.target.classList.contains('btn')) return
   // нажата кнопка clearAll ac
   if (event.target.classList.contains('ac')) return

   out.textContent = ''
   // получаю нажатую кнопку 

   const key = event.target.textContent
   // если нажата кнопка от 0-9 или точка
   if (digit.includes(key)) {
    if (num_one === '' && sign === '') {
        num_one += key
        out.textContent = num_one
    } else if (num_one !== '' && num_two !== '' && finish) {
        num_two = key
        finish = false
        out.textContent = num_two
    } else {
        num_two += key 
        out.textContent = num_two
    }
    console.log(num_one, num_two, sign);
    return
   }

   // если нажата клавиша + - / *
   if (action.includes(key)) {
    sign = key 
    console.log(sign)
    out.textContent = sign 
    return
   }

   // если нажата клавиша равно 

   if (key === '=') {

    if (num_two === '') num_two = num_one

    switch (sign) {
        case '+':
            num_one = Number(num_one) + Number(num_two) 
            break
        case '-':
            num_one = num_one - num_two 
            break
        case 'X':
            num_one = num_one * num_two 
            break
        case '/':
            num_one = num_one / num_two 
            break
    }

    finish = true 
    out.textContent = num_one
    console.log(num_one, num_two, sign);

   }

}